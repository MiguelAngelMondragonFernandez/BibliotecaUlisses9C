package com.example.backprestamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackPrestamoApplicationTests {

    @Test
    void contextLoads() {
    }

}
