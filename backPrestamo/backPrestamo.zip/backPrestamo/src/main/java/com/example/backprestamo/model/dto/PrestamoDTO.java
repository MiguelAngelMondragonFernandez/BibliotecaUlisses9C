package com.example.backprestamo.model.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrestamoDTO {
    private Long id_prestamo;

    private LocalDate fechaSolicitud;

    private LocalDate fechaEntrega;

    private Long libroId;

    private Long usuarioId;

    private Boolean status;


}
