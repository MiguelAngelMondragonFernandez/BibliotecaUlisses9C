package com.example.backprestamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackPrestamoApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackPrestamoApplication.class, args);
    }

}
